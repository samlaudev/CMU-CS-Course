#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <math.h>

int main(int argc, char *argv[]) {

    extern char *optarg;
    extern int optind, opterr, optopt;

    int helpFlag = 0;
    int errorFlag = argc == 4 || argc == 3;

    char arg;
    float a = -1;
    float b = -1;
    float c = -1;

    while ((arg = getopt(argc, argv, "ha:b:c:")) != -1) {
        switch (arg) {
            case 'h':
                helpFlag = 1;
                break;
            case 'a':
                a = atof(optarg);
                break;
            case 'b':
                b = atof(optarg);
                break;
            case 'c':
                c = atof(optarg);
                break;
            case '?':
            default:
                errorFlag = 1;
                break;
        }
    }

    if (errorFlag || helpFlag) {
        fprintf(stderr, "usage: ...");
        exit(errorFlag);
    }

    if (a == -1 && b != -1 && c != -1) {
        a = sqrt(c * c - b * b);
        printf("a = %f\n", a);
    }
    else if (a != -1 && b == -1 && c != -1) {
        b = sqrt(c * c - a * a);
        printf("b = %f\n", b);
    }
    else if (a != -1 && b != -1 && c == -1) {
        c = sqrt(a * a + b * b);
        printf("c = %f\n", c);
    }
    else if (a != -1 && b != -1 && c != -1) {
        int match = c == sqrt(a * a + b * b);
        printf("Those values %s work\n", match ? "do" : "don't");
    }

    return 0;
}